# SigmundBOT: Mastodon Personality Bot

## 🔍 Features
- Responds to Mastodon followers and mentions
- Offers multiple personality tests (Big Five, MBTI, Stoicism, etc.)
- Saves results to CSV and uploads to Google Sheets
- Deployable via GitHub, Replit, or Railway

## 🛠 Setup Guide
1. Create a Mastodon account & register an application.
2. Create a Google Cloud project and enable Sheets API.
3. Clone this repo and copy `.env.example` to `.env`, then fill it out.
4. Deploy to Replit/Railway or configure GitHub Actions for hosting.

## ✅ Psychometric Tests Included
- Big Five Personality
- MBTI (Open-source structure)
- Stoicism (based on open questionnaires)

## 🛡 Security
- Use `.env` to keep secrets out of code
- Never commit `.env` to GitHub
- Revoke & regenerate tokens periodically

See full instructions in the documentation folder.
