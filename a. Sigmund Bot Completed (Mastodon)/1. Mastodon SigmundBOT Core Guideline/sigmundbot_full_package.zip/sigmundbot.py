# sigmundbot.py
# Main Mastodon personality bot

from dotenv import load_dotenv
import os

load_dotenv()

MASTODON_ACCESS_TOKEN = os.getenv('MASTODON_ACCESS_TOKEN')

def main():
    print("Bot is ready! Connect to Mastodon using the access token.")

if __name__ == '__main__':
    main()
